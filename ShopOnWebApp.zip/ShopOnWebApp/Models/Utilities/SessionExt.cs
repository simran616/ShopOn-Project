﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopOnWebApp.Models.Utilities
{
    public static class SessionExt
    {
        public static T GetSession<T>(this ISession session, string key)
        {
            var data = session.GetString(key);
            return data == null ? default : JsonConvert.DeserializeObject<T>(data);            
        }

        public static void SetSession<T>(this ISession session, string key,Object value)
        {
            session.SetString(key, JsonConvert.SerializeObject(value));
        }
    } 
}

