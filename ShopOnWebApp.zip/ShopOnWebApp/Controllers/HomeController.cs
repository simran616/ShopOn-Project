﻿using BusinessLayer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ShopOnWebApp.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ShopOnWebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ProductManager productManager;

        public HomeController(ILogger<HomeController> logger, ProductManager productManager)
        {
            _logger = logger;
            this.productManager = productManager;
        }

        public IActionResult Index()
        {
            var products = this.productManager.GetProducts();
            return View(products);
        }

        public IActionResult Details(int pid)
        {
            var product = this.productManager.GetProduct(pid);
            return View(product);
        }
        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Search(string key)
        {
            //if(!string.IsNullOrEmpty(key))
            if(key !=null)
            {
                var product = this.productManager.ShowProducts(key);
                return View("Index", product);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
