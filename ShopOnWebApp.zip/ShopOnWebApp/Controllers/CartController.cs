﻿using BusinessLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ShopOnWebApp.Models;
using ShopOnWebApp.Models.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopOnWebApp.Controllers
{
    public class CartController : Controller
    {
        private readonly ProductManager productManager;
        public CartController(ProductManager productManager)
        {
            this.productManager = productManager;
        }
        public IActionResult AddToCart(int pid)
        {
            try
            {
                var product = this.productManager.GetProduct(pid);
                if (product != null)
                {
                    var cart = new CartVM()
                    {
                        ImageUrl = product.imageURL,
                        ProductName = product.productName,
                        Price = product.price,
                        pid = product.pid,
                        Qty = 1,
                        Amount = product.price * 1
                    };
                    TempData["cartData"] = JsonConvert.SerializeObject(cart);
                    var cartVMs = HttpContext.Session.GetSession<List<CartVM>>("cartData");
                    if (cartVMs == null)
                    {
                        cartVMs = new List<CartVM>();
                    }
                    var item = cartVMs.FirstOrDefault(x => x.pid == pid);
                    if (item == null)
                    {
                        cartVMs.Add(cart);
                    }
                    else
                    {
                        if (item.Qty >= 5)
                        {
                            ViewBag.MaxQty = $"MAx limit of {item.ProductName} reached";
                        }
                        else
                        {
                            item.Qty = item.Qty + 1;
                            item.Amount = item.Qty * item.Price;
                        }
                    }
                    HttpContext.Session.SetSession<List<CartVM>>("cartData", cartVMs);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);               
            }            
            
            return RedirectToAction("ViewCartDetails");
        }

        public IActionResult ViewCartDetails()
        {
            var cartVMs = HttpContext.Session.GetSession<List<CartVM>>("cartData");
            try
            {                
                var cartCount = 0;
                if (cartVMs != null)
                {
                    cartCount = cartVMs.Count;
                }
                ViewBag.CartCount = cartCount;
                HttpContext.Session.SetInt32("CartCnt",cartCount);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }            
           
            return View(cartVMs);
        }

        public IActionResult RemoveCartData(int id)
        {
            try
            {
                var cartVMs = HttpContext.Session.GetSession<List<CartVM>>("cartData");
                var itemToRemove = cartVMs.FirstOrDefault(x => x.pid == id);
                if (itemToRemove != null)
                {
                    cartVMs.Remove(itemToRemove);
                    HttpContext.Session.SetSession<List<CartVM>>("cartData", cartVMs);
                    TempData["RemoveMessage"] = $"Item With {itemToRemove.ProductName} Removed!";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);                
            }
            
            return RedirectToAction("ViewCartDetails");
        }

        public IActionResult UpdateQty(int pid, int qty)
        {
            try
            {
                var cartVMs = HttpContext.Session.GetSession<List<CartVM>>("cartData");
                var item = cartVMs.FirstOrDefault(x => x.pid == pid);
                item.Qty = qty;
                item.Amount = item.Price * qty;
                HttpContext.Session.SetSession<List<CartVM>>("cartData", cartVMs);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);               
            }
            
            return RedirectToAction("ViewCartDetails");
        }
        public IActionResult BuyNow(int pid)
        {
            return View();
        }
    }
}
