﻿using BusinessLayer.Contract;
using CommonLayer.Model;
using DataAccessLayer.Contract;
using DataAccessLayer.DBimpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class OrderManager : IOrderManager
    {
        private IOrderRepository orderRepo = null;
        public OrderManager()
        {
            this.orderRepo = new OrderRepositoryDBImpl();
        }
        public bool AddOrder(Order order) => orderRepo.AddOrder(order);

        public bool DeleteOrder(int id) => orderRepo.DeleteOrder(id);

        public IEnumerable<Order> GetOrders() => orderRepo.GetOrders();

        public bool UpdateOrder(Order order) => orderRepo.UpdateOrder(order);
        
    }
}
