﻿using BusinessLayer.Contract;
using CommonLayer.Model;
using DataAccessLayer.Contract;
using DataAccessLayer.DBimpl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class CompanyManager :ICompanyManager
    {
        private ICompanyRepository companyRepo= null;
        public CompanyManager()
        {
            this.companyRepo = new CompanyRepositoryDBImpl();
        }
        public Company GetCompany(int id) => this.companyRepo.GetCompany(id);

        public IEnumerable<Company> GetCompanyDetails() => this.companyRepo.GetCompanyDetails();
        public bool InsertCompany(Company company) => this.companyRepo.InsertCompany(company);
        public bool UpdateCompany(Company company) => this.companyRepo.UpdateCompany(company);
        public IEnumerable<Product> GetSearchedCompany(int id) => this.companyRepo.GetSearchedCompany(id);
        public bool DeleteCompany(Company company) => this.companyRepo.DeleteCompany(company);
    }
}
