﻿using BusinessLayer.Contract;
using CommonLayer.Model;
using DataAccessLayer.Contract;
using EntityDataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class OfferManager : IOfferManager
    {
        private IOfferRepository offerRepo = null;
        public OfferManager()
        {
            this.offerRepo = new OfferRepositoryEntityImpl();
        }
        public bool AddOffer(Offer offer)
        {
            throw new NotImplementedException();
        }

        public bool DeleteOffer(int offerId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Offer> GetOffers()
        {
            throw new NotImplementedException();
        }

        public bool UpdateOffer(Offer offer)
        {
            throw new NotImplementedException();
        }
    }
}
