﻿using CommonLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Utilities
{
    public class CompareByID : IComparer<Product>
    {
        public int Compare(Product x, Product y)
        {
            return (x.price.CompareTo(y.price));
        }
    }
}
