﻿using BusinessLayer.Contract;
using BusinessLayer.Utilities;
using CommonLayer.Model;
using DataAccessLayer;
using DataAccessLayer.Contract;
using EntityDataLayer;
using ShopOn;
using System;
using System.Collections.Generic;

namespace BusinessLayer
{
    public class ProductManager : Contract.IProductManager
    {
        private ProductRepoInMemory productRepo = null;
        private ProductRepoListImpl productRepoList = null;
        private DataAccessLayer.Contract.IProductManager productRepoDB = null;
        private IDatabaseRepository dbRepo = null;
        
        
        public ProductManager(IDatabaseRepository productRepo )
        {           
            //this.productRepo = new ProductRepoInMemory(20);
            this.productRepoList = new ProductRepoListImpl();
            //this.dbRepo = new ProductRepositoryEntityImpl();
            this.dbRepo = productRepo;
        }

        public bool AddProduct(Product product)=> this.productRepoList.InsertRecord(product);      

        public bool AddProductByList(Product product) => this.productRepoList.InsertRecord(product);
        public IEnumerable<Product> ShowProductByList()=>this.productRepoList.GetRecords();
        public Product UpdateProduct(Product product) => this.productRepoList.UpdateRecords(product);
        public bool DeleteProduct(int id) => this.productRepoList.DeleteRecords(id);
        public Product ShowSearchedRecords(int id) => this.productRepoList.GetProduct(id);
        public List<Product> SortByPrice() => this.productRepoList.SortByPrice();
        public List<Product> SortByName() => this.productRepoList.SortByName();
        IEnumerable<Product> Contract.IProductManager.SortByPrice()
        {
            throw new NotImplementedException();
        }
        IEnumerable<Product> Contract.IProductManager.SortByName()
        {
            throw new NotImplementedException();
        }
        public IEnumerable<Product> GetProducts() => this.dbRepo.GetProductFromDB(true);
        public IEnumerable<Customer> GetCustomers() => this.dbRepo.GetCustomersDetails();
        public bool AddRecord(Product product) => this.dbRepo.InsertProduct(product);
        public IEnumerable<Product> ShowSearchedProducts(int id) => this.dbRepo.GetSearchedProduct(id);
        public bool UpdateProductByID(Product product) => this.dbRepo.UpdateProduct(product);
        public bool DeleteProductByID(int id) => this.dbRepo.DeleteProduct(id);
        public Product GetProduct(int id) => this.dbRepo.GetProduct(id);

        public IEnumerable<Product> ShowProducts(string key) => this.dbRepo.ShowProducts(key);
    }
}
