﻿using BusinessLayer.Contract;
using CommonLayer.Model;
using DataAccessLayer.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class ProductManagerAsync : IProductManagerAsync
    {
        private readonly IProductRepoAsync productRepoAsync;

        public ProductManagerAsync(IProductRepoAsync productRepoAsync)
        {
            this.productRepoAsync = productRepoAsync;
        }
        public Task<Product> AddProduct(Product product) => this.productRepoAsync.AddProduct(product);

        public Task Delete(int id) => this.productRepoAsync.Delete(id);

        public Task<Product> GetProduct(int id) => this.productRepoAsync.GetProduct(id);

        public Task<IEnumerable<Product>> GetProducts() => this.productRepoAsync.GetProducts();

        public Task<IEnumerable<Product>> Search(string key) => this.productRepoAsync.Search(key);

        public Task<Product> Update(Product product) => this.productRepoAsync.Update(product);
    }
}
