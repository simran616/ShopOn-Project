﻿using CommonLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Contract
{
    public interface IOfferManager
    {
        bool AddOffer(Offer offer);
        bool UpdateOffer(Offer offer);
        bool DeleteOffer(int offerId);
        public IEnumerable<Offer> GetOffers();
    }
}
