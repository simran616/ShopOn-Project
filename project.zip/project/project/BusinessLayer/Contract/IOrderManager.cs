﻿using CommonLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Contract
{
    public interface IOrderManager
    {
        public IEnumerable<Order> GetOrders();
        public bool UpdateOrder(Order order);
        public bool AddOrder(Order order);
        public bool DeleteOrder(int id);
    }
}
