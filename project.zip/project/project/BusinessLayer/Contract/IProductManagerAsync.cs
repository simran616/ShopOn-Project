﻿using CommonLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Contract
{
    public interface IProductManagerAsync
    {
        /// <summary>
        /// Method to add product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        Task<Product> AddProduct(Product product);

        /// <summary>
        /// Method to show all products
        /// </summary>
        /// <returns></returns>
        public Task<IEnumerable<Product>> GetProducts();

        /// <summary>
        /// method ot search a product
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public Task<IEnumerable<Product>> Search(string key);

        /// <summary>
        /// method to show only one product
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<Product> GetProduct(int id);

        /// <summary>
        /// method to update product
        /// </summary>
        /// <param name="id"></param>
        /// <param name="product"></param>
        /// <returns></returns>
        public Task<Product> Update(Product product);

        /// <summary>
        /// method to delete product
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task Delete(int id);
    }
}
