﻿using CommonLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Contract
{
    public interface IBankManager 
    {
        bool AddBank(Bank bank);
        bool UpdateBank(Bank bank);
        bool DeleteBank(int bankId);
        public IEnumerable<Bank> GetBanks();
    }
}
