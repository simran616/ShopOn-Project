﻿using CommonLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Contract
{
    interface IProductManager
    {
        bool AddProductByList(Product product);
        IEnumerable<Product> ShowProductByList();
        IEnumerable<Product> GetProducts();
        IEnumerable<Customer> GetCustomers();
        bool DeleteProduct(int id);
        Product UpdateProduct(Product product);
        Product ShowSearchedRecords(int id);
        IEnumerable<Product> SortByPrice();
        IEnumerable<Product> SortByName();
        public Product GetProduct(int id);

        public IEnumerable<Product> ShowProducts(string key);
    }
}
