﻿using BusinessLayer.Contract;
using CommonLayer.Model;
using DataAccessLayer.Contract;
using EntityDataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class BankManager : IBankManager
    {
        private IBankRepository bankRepo = null;
        public BankManager()
        {
            this.bankRepo = new BankRepositoryEntityImpl();
        }
        public bool AddBank(Bank bank) => this.bankRepo.AddBank(bank);
        

        public bool DeleteBank(int bankId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Bank> GetBanks()
        {
            throw new NotImplementedException();
        }

        public bool UpdateBank(Bank bank)
        {
            throw new NotImplementedException();
        }
    }
}
