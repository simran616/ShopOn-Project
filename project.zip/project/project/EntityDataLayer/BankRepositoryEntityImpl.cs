﻿using CommonLayer.Model;
using DataAccessLayer.Contract;
using EntityDataLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityDataLayer
{
    public class BankRepositoryEntityImpl : IBankRepository
    {
        private db_ShoponContext context = null;
        public BankRepositoryEntityImpl()
        {
            this.context = new db_ShoponContext();
        }
        public bool AddBank(CommonLayer.Model.Bank bank)
        {
            bool isAdded = false;
            try
            {
                var dbBank = this.context.Banks.FirstOrDefault(x => x.IFSC == bank.IFSC);
                if(dbBank==null)
                {
                    isAdded = SaveBankData(bank);
                    
                }
                else
                {
                    isAdded = SaveOffers(bank.offers, bank.BankId);
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);

            }           
            return isAdded;
        }

        private bool SaveOffers(ICollection<CommonLayer.Model.Offer> offers, int bankId)
        {
            bool isAdded = false;
            var dbOffers = GetDbOffers(offers);
            foreach(var offer in dbOffers)
            {
                offer.BankId= bankId;
                this.context.Offers.Add(offer);
                this.context.SaveChanges();
            }
            return isAdded;
        }

        private bool SaveBankData(CommonLayer.Model.Bank bank)
        {
            bool isAdded = false;
            var bankdata = new Models.Bank()
            {
                BankName = bank.BankName,
                City = bank.City,
                IFSC = bank.IFSC                
            };
            this.context.Banks.Add(bankdata);
            this.context.SaveChanges();
            return isAdded;
        }

        private IEnumerable<Models.Offer> GetDbOffers(ICollection<CommonLayer.Model.Offer> offers)
        {
            var dbOffers = from o in offers
                           select new Models.Offer
                           {
                               Discount = o.Discount,
                               OfferTime = o.OfferTime,
                               OfferType = o.OfferType,
                               Remark = o.Remark,
                               BankId=o.BankId


                           };
                           return dbOffers.ToList();
        }

        public bool DeleteBank(int bankId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<CommonLayer.Model.Bank> GetBanks()
        {
            throw new NotImplementedException();
        }

        public bool UpdateBank(CommonLayer.Model.Bank bank)
        {
            throw new NotImplementedException();
        }
    }
}
