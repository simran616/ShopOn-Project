﻿using CommonLayer.Model;
using DataAccessLayer;
using DataAccessLayer.Contract;
using EntityDataLayer.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityDataLayer
{
    public class ProductRepoAsyncImpl : IProductRepoAsync
    {
        private readonly db_ShoponContext context;

        public ProductRepoAsyncImpl(db_ShoponContext context)
        {
            this.context = context;
        }

        /// <summary>
        /// method to update product
        /// </summary>
        /// <param name="id"></param>
        /// <param name="product"></param>
        /// <returns></returns>
        public async Task<CommonLayer.Model.Product> Update(CommonLayer.Model.Product product)
        {
            var productToUpdate = await this.context.Products.FirstOrDefaultAsync(x => x.Pid == product.pid);
            if (productToUpdate != null)
            {
                productToUpdate.Availablestatus = product.availablestatus;                
                productToUpdate.Price = product.price;
                productToUpdate.Companyid = product.CompanyId;
                productToUpdate.Categoryid = product.CategoryId;
                productToUpdate.ImageUrl = product.imageURL;
                productToUpdate.Productname = product.productName;
                await this.context.SaveChangesAsync();
                return product;
            }
            return null;
        }

        /// <summary>
        /// Method to add product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public async Task<CommonLayer.Model.Product> AddProduct(CommonLayer.Model.Product product)
        {
            var productDb = new Models.Product()
            {
                Productname = product.productName,
                Price = product.price,
                Availablestatus = product.availablestatus,
                Companyid = product.CompanyId,
                Categoryid = product.CategoryId,
                ImageUrl = product.imageURL,
                IsDeleted = false
            };
            var result = await this.context.Products.AddAsync(productDb);
            await context.SaveChangesAsync();
            return new CommonLayer.Model.Product()
            {
                availablestatus = result.Entity.Availablestatus,
                productName = result.Entity.Productname,
                price = result.Entity.Price.Value,
                CompanyId = result.Entity.Companyid.Value,
                CategoryId = result.Entity.Categoryid.Value,
                imageURL = result.Entity.ImageUrl,
                //isDeleted =result.Entity.IsDeleted
            };
        }

        /// <summary>
        /// method to delete product
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task Delete(int id)
        {
            var productToDelete = this.context.Products.FirstOrDefaultAsync(x => x.Pid == id);
            if(productToDelete!=null)
            {
                this.context.Products.Remove(await productToDelete);
                await this.context.SaveChangesAsync();
            }    
        }

        /// <summary>
        /// method to show only one product
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<CommonLayer.Model.Product> GetProduct(int id)
        {
            var result = await this.context.Products
                        .Include(p => p.Company)
                        .FirstOrDefaultAsync(p => p.Pid == id);
            if(result !=null)
            {
                var company = new CommonLayer.Model.Company()
                {
                    companyId = result.Company.Companyid,
                    companyName = result.Company.Companyname
                };
                return new CommonLayer.Model.Product()
                {
                    availablestatus = result.Availablestatus,
                    productName = result.Productname,
                    price = result.Price.Value,
                    CompanyId = result.Companyid.Value,
                    CategoryId = result.Categoryid.Value,
                    imageURL = result.ImageUrl,
                    Company = company

                };
                    
            }
            return null; 
        }

        /// <summary>
        /// Method to show all products
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<CommonLayer.Model.Product>> GetProducts()
        {
            try
            {
                var result = await this.context.Products.ToListAsync();
                var resultToReturn = (from p in result
                                      select new CommonLayer.Model.Product
                                      {
                                          availablestatus = p.Availablestatus,
                                          productName = p.Productname,
                                          price = p.Price.Value,
                                          CompanyId = p.Companyid.Value,
                                          CategoryId = p.Categoryid.Value,
                                          imageURL = p.ImageUrl,
                                          pid=p.Pid

                                      }
                                      ).ToList();
                return resultToReturn;

            }
            catch (Exception e)
            {

                Console.WriteLine(e.Message);
            }
            return null;
        }

        /// <summary>
        /// method ot search a product
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public async Task<IEnumerable<CommonLayer.Model.Product>> Search(string key)
        {
            IQueryable<Models.Product> query = this.context.Products;
            if (!string.IsNullOrEmpty(key))
            {
                query = query.Where(p => p.Productname.Contains(key));
            }
            var result = await query.ToListAsync();
            var resultToReturn = (from p in result
                                  select new CommonLayer.Model.Product
                                  {
                                      availablestatus = p.Availablestatus,
                                      productName = p.Productname,
                                      price = p.Price.Value,
                                      CompanyId = p.Companyid.Value,
                                      CategoryId = p.Categoryid.Value,
                                      imageURL = p.ImageUrl

                                  }
                                  ).ToList();
            return resultToReturn;
        }
      
    }
}
