﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityDataLayer.Models
{
    public class Bank
    {
        public Bank()
        {
            this.offers = new List<Offer>();
        }
        public int BankId { get; set; }
        public string BankName { get; set; }
        public string City { get; set; }
        public string IFSC { get; set; }
        public IEnumerable<Offer> offers { get; set; }
    }
}
