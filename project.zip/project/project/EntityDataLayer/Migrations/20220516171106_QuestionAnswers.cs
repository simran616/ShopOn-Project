﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EntityDataLayer.Migrations
{
    public partial class QuestionAnswers : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CustomerQuestion",
                columns: table => new
                {
                    CustomerQueryID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    QuesDes = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CustomerQuestion", x => x.CustomerQueryID);
                });

            migrationBuilder.CreateTable(
                name: "CustomerAnswers",
                columns: table => new
                {
                    AnswerID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AnsDes = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    QuestionID = table.Column<int>(type: "int", nullable: false),
                    QuestionsQuestionID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CustomerAnswers", x => x.AnswerID);
                    table.ForeignKey(
                        name: "FK_CustomerAnswers_CustomerQuestion_QuestionsQuestionID",
                        column: x => x.QuestionsQuestionID,
                        principalTable: "CustomerQuestion",
                        principalColumn: "CustomerQueryID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_CustomerAnswers_QuestionsQuestionID",
                table: "CustomerAnswers",
                column: "QuestionsQuestionID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CustomerAnswers");

            migrationBuilder.DropTable(
                name: "CustomerQuestion");
        }
    }
}
