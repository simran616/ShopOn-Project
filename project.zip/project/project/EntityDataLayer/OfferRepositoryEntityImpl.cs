﻿using CommonLayer.Model;
using DataAccessLayer.Contract;
using EntityDataLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityDataLayer
{
    public class OfferRepositoryEntityImpl : IOfferRepository
    {
        private db_ShoponContext context =null;
        public OfferRepositoryEntityImpl()
        {
            this.context = new db_ShoponContext();
        }
        public bool AddOffer(CommonLayer.Model.Offer offer)
        {
            throw new NotImplementedException();
        }

        public bool DeleteOffer(int offerId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<CommonLayer.Model.Offer> GetOffers()
        {
            throw new NotImplementedException();
        }

        public bool UpdateOffer(CommonLayer.Model.Offer offer)
        {
            throw new NotImplementedException();
        }
    }
}
