﻿using EntityDataLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityDataLayer
{
    public class CustomerRating
    {
        public int ReviewId { get; set; }
        public int ProductRating { get; set; }
        public int ProductId { get; set; }
        public Product Product { get; set; }
    }

}
