﻿using CommonLayer.Model;
using DataAccessLayer.Contract;
using EntityDataLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityDataLayer
{
    public class ProductRepositoryEntityImpl : IDatabaseRepository
    {
        private db_ShoponContext context = null;
        public ProductRepositoryEntityImpl()
        {
            this.context = new db_ShoponContext();
        }

        public bool DeleteProduct(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Customer> GetCustomersDetails()
        {
            throw new NotImplementedException();
        }

        public CommonLayer.Model.Product GetProduct(int id)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Method to get all products using eager loading
        /// </summary>
        /// <param name="isEagerLoad"></param>
        /// <returns></returns>
        public IEnumerable<CommonLayer.Model.Product> GetProductFromDB(bool isEagerLoad = false)
        {
            var products = this.context.Products
                         .Join(this.context.Companies, p => p.Companyid, c => c.Companyid,
                         (p, c) => new CommonLayer.Model.Product
                         {
                             availablestatus=p.Availablestatus,
                             CategoryId=p.Categoryid.Value,
                             pid =p.Pid,
                             price =p.Price.Value,
                             productName=p.Productname,
                             Company=new CommonLayer.Model.Company()
                             {
                                 companyId=c.Companyid,
                                 companyName=c.Companyname,
                                 companyStatus=c.Companystatus
                                 
                             }
                         }
                         );
            //var dataProduct = this.context.Products.ToList();
            //var products = from p in dataProduct
            //               select new CommonLayer.Model.Product
            //               {
            //                   pid = p.Pid,
            //                   productName = p.Productname,
            //                   CompanyId = p.Companyid.Value,
            //                   CategoryId = p.Categoryid.Value,
            //                   availablestatus = p.Availablestatus,
            //                   price = p.Price.Value,
            //                   imageURL = p.ImageUrl
            //               };
            return products;
        }

        public IEnumerable<CommonLayer.Model.Product> GetSearchedProduct(int id)
        {
            throw new NotImplementedException();
                    
            
        }
        /// <summary>
        /// method to add a new product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool InsertProduct(CommonLayer.Model.Product product)
        {
            bool isInserted = false;
            try
            {
                var dataProduct = new Models.Product()
                { 
                    Availablestatus=product.availablestatus,
                    Productname=product.productName,                    
                    Companyid=product.CompanyId,
                    Categoryid=product.CategoryId,
                    Price=product.price,
                    ImageUrl=product.imageURL,
                    IsDeleted=false
                };
                this.context.Products.Add(dataProduct);
                this.context.SaveChanges();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
            return isInserted;
        }

        public IEnumerable<CommonLayer.Model.Product> ShowProducts(string key)
        {
            throw new NotImplementedException();
        }

        public bool UpdateProduct(CommonLayer.Model.Product product)
        {
            throw new NotImplementedException();
        }
    }
}
