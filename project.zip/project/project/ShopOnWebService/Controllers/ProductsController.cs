﻿using BusinessLayer.Contract;
using CommonLayer.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopOnWebService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductManagerAsync productManagerAsync;

        public ProductsController(IProductManagerAsync productManagerAsync)
        {
            this.productManagerAsync = productManagerAsync;
        }

        
        //GET: /api/Products
        public async Task<IActionResult> Get()
        {
            try
            {
                var products = await productManagerAsync.GetProducts();
                return Ok(products);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error retriving products from server.");
            }
        }

        //Get : /api/product/5
        [HttpGet("{id:int}")] // route constraint int : pass only numbers
        public async Task<IActionResult> Getproduct(int id)
        {
            try
            {
                var product = await productManagerAsync.GetProduct(id);
                if(product == null)
                {
                    return NotFound();
                }
                
                return Ok(product);
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status404NotFound, "No Product found.");
            }
        }

        //Post : api/product
        [HttpPost]
        public async Task<ActionResult<Product>> Create(Product product)
        {
            try
            {
                if (product == null)
                {
                    return BadRequest();
                }
                else
                {
                    var result = await this.productManagerAsync.AddProduct(product);
                    return CreatedAtAction(nameof(Get), new { id = result.pid }, result);
                }
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status404NotFound, "Error Creating new product");
            }
        }

        //DELETE: /api/Products/5
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await productManagerAsync.Delete(id);
                return Ok($"Product with id {id} deleted successfully");
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                                    "Error retriving products from server.");
            }
        }

        // Get : /api/product/search
        [HttpGet("{search}")]
        public async Task<ActionResult> SearchProduct(string key)
        {
            try
            {
                var result = await this.productManagerAsync.Search(key);
                if (result.Any())
                {
                    return Ok(result);
                }
                return NotFound($"Product with key {key} not found");
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status404NotFound, "Error Creating new product");
            }
        }
    }
}
