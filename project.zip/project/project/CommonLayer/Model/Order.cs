﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLayer.Model
{
    public class Order
    {
        public int OrderId { get; set; }
        public DateTime orderDate { get; set; }
        public double OrderAmount { get; set; }
        public Customer customer { get; set; }
        public int CustomerId { get; set; }
        public string OrderStatus { get; set; }
        public List<OrderItem> orderItems = new List<OrderItem>();
        public void AddOrderItem(OrderItem orderItem)
        {
            this.orderItems.Add(orderItem);
        }
        public IEnumerable<OrderItem> GetOrderItems()
        {
            return this.orderItems;
        }
        public double GetTotalOrderValue()
        {
            double total = 0;
            foreach(var item in this.orderItems)
            {
                total += item.GetOrderAmount();
            }
            return total;
        }
    }
}
