﻿

using System;

namespace CommonLayer.Model
{
    public class Product : IComparable<Product>
    {
        public int pid { get; set; }
        public string productName { get; set; }
        public double price { get; set; }
        public string availablestatus { get; set; }
        public string imageURL { get; set; }
        public int isDeleted { get; set; }
        public int CompanyId { get; set; }
        public int CategoryId { get; set; }
        public Company Company { get; set; }

        public int CompareTo(Product other)
        {
            if (this.pid > other.pid)
            {
                return 1;
            }
            else if(this.pid < other.pid)
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }
    }
}
