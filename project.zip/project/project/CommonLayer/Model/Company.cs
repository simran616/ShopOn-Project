﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLayer.Model
{
    public class Company
    {
        public int companyId { get; set; }
        public string companyName { get; set; }
        public string companyStatus { get; set; }
        public byte isDeleted { get; set; }
    }
}
