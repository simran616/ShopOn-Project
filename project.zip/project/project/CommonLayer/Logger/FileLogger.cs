﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLayer.Logger
{
    public class FileLogger : ILogger
    {
        string path =string.Empty;
        public FileLogger()
        {
            path = @"D:\Logs\logs.txt";            
        }
        //application location path, by default


    public void LogContent(string customerErrorMsg, string stackTrace, DateTime dateTime)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(path,true))
                {
                    sw.WriteLine(customerErrorMsg+" "+stackTrace+" "+dateTime);
                }
            }
            catch (Exception)
            {
                throw;
            }            
        }

        public void LogContent(string customerErrorMsg)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(path, true))
                {
                    sw.WriteLine(customerErrorMsg);
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
