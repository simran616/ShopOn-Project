﻿using System;

namespace CommonLayer.Logger
{
    public interface ILogger
    {
      //  void LogContent(string customerErrorMsg, string stackTrace);
        void LogContent(string customerErrorMsg, string stackTrace, DateTime dateTime);
        void LogContent(string customerErrorMsg);


    }
}