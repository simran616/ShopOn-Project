﻿using BusinessLayer;
using BusinessLayer.Utilities;
using CommonLayer.Logger;
using CommonLayer.Model;
using DataAccessLayer;
using DataAccessLayer.Contract;
using System;
using System.Collections.Generic;

namespace ShopOn
{
    public class Program 
    {

        #region Menu 
        static void Main(string[] args)
        {
            IProductManager productRepository = new ProductRepoListImpl();
            IDatabaseRepository databaseRepository = new ProductRepoDBImpl();
            //ProductManager manager = new ProductManager();
            OrderManager orderManager = new OrderManager();
            CompanyManager companyManager = new CompanyManager();
            BankManager bankManager = new BankManager();
            OfferManager offerManager = new OfferManager();
            CompareByName compareByName = new CompareByName();

            
            Product product = new Product();
            Order order = new Order();
            int n = 0;
            do
            {
                Console.WriteLine("Main Menu");
                Console.WriteLine("1. Insert Records");
                Console.WriteLine("2. Display Records");
                Console.WriteLine("3. Update records");
                Console.WriteLine("4. Delete Records");
                Console.WriteLine("5. Sort Records by Price");
                Console.WriteLine("6. Sort Records by Name");
                Console.WriteLine("7. Search Records by ID");
                Console.WriteLine("8. Product Operation Menu ");
                Console.WriteLine("9. Insert Order Details");
                Console.WriteLine("10. Get Order Details of Customer");
                Console.WriteLine("11. Create New Order");
                Console.WriteLine("12. Display Companies Data");
                Console.WriteLine("13. Insert Company");
                Console.WriteLine("14. Update Company");
                Console.WriteLine("15. Delete Company");
                Console.WriteLine("16. Add Bank Data");
                Console.WriteLine("17. Exit");
                Console.WriteLine("Select your choice: ");
                n = int.Parse(Console.ReadLine());

                switch (n)
                {
                    case 1:
                        //InsertRecords(manager);
                        break;
                    case 2:
                        //ShowRecords(manager);
                        break;
                    case 3:
                        Console.WriteLine("please provide the ID for which you want to update-");
                        int id = int.Parse(Console.ReadLine());
                        //UpdateRecord(manager, id);
                        break;
                    case 4:
                        Console.WriteLine("Please provide the ID for which you want to delete-");
                        int delid = int.Parse(Console.ReadLine());
                        //DeleteRecord(manager, delid);
                        break;
                    case 5:
                       
                        //SortByPrice(manager);
                        break;
                    case 6:
                        //SortByName(manager);
                        break;
                    case 7:
                        Console.WriteLine("Please provide the ID you want to search-");
                        int searchid = int.Parse(Console.ReadLine());
                        //SearchByID(manager, searchid);
                        break;
                    case 8:                        
                        //SQLOperations(manager);
                        break;
                    case 9:
                        InsertOrder(orderManager);
                        break;
                    case 10:
                        GetAllOrders(orderManager);
                        break;
                    case 11:
                        CreateOrder(orderManager);
                        break;
                    case 12:
                        GetCompanyData(companyManager);
                        break;
                    case 13:
                        InsetCompany(companyManager);
                        break;
                    case 14:
                        Console.WriteLine("Please provide the ID you want to update-");
                        int updateid = int.Parse(Console.ReadLine());
                        UpdateCompany(companyManager,updateid);
                        break;
                    case 15:
                        Console.WriteLine("Please provide the ID you want to delete-");
                        int deleteid = int.Parse(Console.ReadLine());
                        DeleteCompany(companyManager,deleteid);
                        break;
                    case 16:
                        AddBank(bankManager);
                        break;
                    case 17:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Incorrect choice");
                        break;
                }

            } while (n != 17);
           
        }

        private static void AddBank(BankManager bankManager)
        {
            try
            {
                Bank bank = new Bank()
                {

                    BankName = "HDFC",
                    City = "New Delhi",
                    IFSC = "HDFC001045",

                };
                Offer offer1 = new Offer()
                {

                    Discount = 12,
                    OfferTime = DateTime.UtcNow.AddDays(12),
                    OfferType = "Credit Card",
                    Remark = "Summer Discount"
                };
                Offer offer2 = new Offer()
                {

                    Discount = 16,
                    OfferTime = DateTime.UtcNow.AddDays(12),
                    OfferType = "Debit Card",
                    Remark = "Summer Discount"
                };
                bank.AddOffer(offer1);
                bank.AddOffer(offer2);
                bankManager.AddBank(bank);
                {
                    Console.WriteLine("Bank Details Added Successfully");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Bank Details Not Added");
                Console.WriteLine(e.Message);
                
            }           
            
        }

        public static void DeleteCompany(CompanyManager companyManager, int id)
        {
            Company company = new Company();
            company.companyId = id;
            try
            {
                Company company1 = new Company()
                {
                    companyId=id,
                    companyName = company.companyName,
                    companyStatus =company.companyStatus,
                    isDeleted=company.isDeleted
                };
                companyManager.DeleteCompany(company1);
                Console.WriteLine("Company Updated");
                Console.WriteLine("--------------------------------------------------------");


            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static void UpdateCompany(CompanyManager companyManager, int id)
        {
            Company company = new Company();  
            company.companyId = id;
            try
            {
                Company company1 = new Company()
                {
                    companyId = id,
                    companyName= "Oppo Realme",
                    companyStatus="Y",
                    isDeleted=0
                };
                companyManager.UpdateCompany(company1);
                
                Console.WriteLine("Company Updated");
                Console.WriteLine("--------------------------------------------------------");
                
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
        }

        public static void InsetCompany(CompanyManager companyManager)
        {
            Company company = new Company();
            try
            {
                Company company1 = new Company()
                {
                    companyName="Realme",
                    companyStatus="Y",
                    isDeleted=0

                };
                if (companyManager.InsertCompany(company1))
                {
                    Console.WriteLine("Company Inserted");

                    Console.WriteLine("--------------------------------------------------------");
                }
                else
                {
                    Console.WriteLine("Company Not Inserted");
                    Console.WriteLine("--------------------------------------------------------");
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public static void GetCompanyData(CompanyManager companyManager)
        {
            Console.WriteLine("Company ID \t Company Name");
            Console.WriteLine("--------------------------------------------------------------------------------------------");
            try
            {
                foreach (var company in companyManager.GetCompanyDetails())
                    if (company != null)
                    {
                        Console.WriteLine($"{company.companyId} \t \t {company.companyName}");

                    }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static void SQLOperations(ProductManager manager)
        {
            int s;
            do
            {
                Console.WriteLine("-------------------------------------------------------");
                Console.WriteLine("Database Operations-");
                Console.WriteLine("1. Show Product Details");
                Console.WriteLine("2. Show Customer Details");
                Console.WriteLine("3. Insert Product");
                Console.WriteLine("4. Update Product");
                Console.WriteLine("5. Search Product");
                Console.WriteLine("6. Delete Product");
                Console.WriteLine("7. Go Back to Previous Menu");
                Console.WriteLine("Select your choice: ");
                s = int.Parse(Console.ReadLine());
                switch(s)
                {
                    case 1:
                        DisplayProducts(manager);
                        break;
                    case 2:
                        DisplayCustomers(manager);
                        break;
                    case 3:
                        InsertProducts(manager);
                        break;
                    case 4:
                        Console.WriteLine("please provide the ID for which you want to update-");
                        int id = int.Parse(Console.ReadLine());
                        UpdateProduct(manager, id);
                        break;
                    case 5:
                        Console.WriteLine("please provide the ID for which you want to search product-");
                        int productID = int.Parse(Console.ReadLine());
                        SearchProductByID(manager, productID);
                        break;
                    case 6:
                        Console.WriteLine("please provide the ID for which you want to Delete-");
                        int deleteID = int.Parse(Console.ReadLine());
                        DeleteProduct(manager, deleteID);
                        break;
                    
                    case 7:
                        continue;
                    default:
                        Console.WriteLine("Incorrect choice");
                        break;
                }
            } while (s != 7);
        }
        // create new order
        public static void CreateOrder(OrderManager manager)
        {
            Order order = new Order()
            {
                CustomerId = 1,
                orderDate = DateTime.UtcNow,
                OrderAmount=0
            };
            Product product1 = new Product()
            {
                CategoryId = 2002,
                CompanyId = 1007,
                imageURL = "images/Samsung/57.jpg",
                availablestatus = "Y",
                pid = 57,
                price = 26299,
                productName = "Samsung Galaxy Note-4"
            };
            Product product2 = new Product()
            {
                CategoryId = 2002,
                CompanyId = 1010,
                imageURL = "images/oneplus/nord2_5g.jpg",
                availablestatus = "Y",
                pid = 57,
                price = 39999,
                productName = "One plus Nord 2 5G"
            };

           // List<OrderItem> orderItems = new List<OrderItem>();
            OrderItem orderItems1 = new OrderItem() { product = product1, Pid = 57, Qty = 2 };
            OrderItem orderItems2 = new OrderItem() { product = product2, Pid = 57, Qty = 1 };

            order.AddOrderItem(orderItems1);
            order.AddOrderItem(orderItems2);
            try
            {
                if (manager.AddOrder(order))
                {
                    Console.WriteLine($"Order Created. New Order ID- {order.OrderId}");
                }
                else
                {
                    Console.WriteLine("Order Not Created");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        #endregion
        public static void DisplayProducts(ProductManager manager)
        {
            Console.WriteLine("Product ID \t Product Name \t\t Price \t Company ID \t Category ID \t Available Status \tImage URL \t Company Name");
            try
            {
                foreach(var product in manager.GetProducts())
                    if (product != null)
                    {
                        DisplayRecords(product);
                        Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                        
                    }
                    else
                    {
                        Console.WriteLine("There are no Products to Display");
                        
                        Console.WriteLine("---------------------------------------------------------------------------------------------------------------------");
                    }             
            }
            catch (Exception)
            {
                throw;
            }
        }
        public static void DisplayCustomers(ProductManager manager)
        {
            Console.WriteLine("Customer ID \t Customer Name \t \t Mobile Number \t\t Email ID \t\t\t Password");
            Console.WriteLine("--------------------------------------------------------------------------------------------");
            try
            {
                foreach(var customer in manager.GetCustomers())
                    if (customer !=null)
                    {
                        Console.WriteLine($"{customer.customerid} \t \t {customer.customername} \t \t {customer.mobileno} \t\t {customer.emailid} \t\t{customer.password}");

                    }
            }
            catch(Exception)
            {
                throw;
            }
        }

        public static void InsertProducts(ProductManager manager)
        {
            Product product = new Product();
            try
            {
                Product product1 = new Product()
                {
                    productName = "Realme Master ",
                    price = 28000,
                    CompanyId = 1011,
                    CategoryId = 2002,
                    availablestatus = "Y",
                    imageURL = "images/RealmeMaster/130.jpg",
                    isDeleted=0,                    
                };
                manager.AddRecord(product1);               
                    Console.WriteLine("Product Inserted");
                    Console.WriteLine("--------------------------------------------------------");
                
               
                
            }
            catch (Exception e)
            {
                Console.WriteLine("Product Not Inserted !!!");
                Console.WriteLine(e.Message);
            }
           
        }
        public static void InsertOrder(OrderManager manager)
        {
            Order order = new Order();
            try
            {
                Order order1 = new Order()
                {
                    OrderStatus = "New",
                    orderDate = DateTime.Now,
                    CustomerId=12,
                    OrderAmount=20000                   

                };
                if (manager.AddOrder(order1))
                {
                    Console.WriteLine("Order Inserted");

                    Console.WriteLine("--------------------------------------------------------");
                }
                else
                {
                    Console.WriteLine("Order Not Inserted");
                    Console.WriteLine("--------------------------------------------------------");
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        public static void UpdateProduct(ProductManager manager, int id)
        {
            Product product = new Product();
            try
            {
                product.pid = id;                
                try
                {
                    Product product1 = new Product()
                    {
                        pid=id,
                        productName = "Realme GT NEO 2",
                        price = 35000,
                        CompanyId = 1011,
                        CategoryId = 2002,
                        availablestatus = "Y",
                        imageURL = "images/RealmeNEO2/131.jpg",
                        

                    };
                    if(manager.UpdateProductByID(product1))
                    {
                        Console.WriteLine("Product Updated");
                        Console.WriteLine("--------------------------------------------------------");
                    }
                    else
                    {
                        Console.WriteLine("product not updated !!");
                    }                     
                   
                }
                catch (Exception)
                {
                    throw;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        public static void GetAllOrders(OrderManager manager)
        {
            Console.WriteLine("Order ID\t Order Date \t Order Status");
            Console.WriteLine("--------------------------------------------------------------------------------------------");
            try
            {
                foreach (var order in manager.GetOrders())
                    if (order != null)
                    {
                        Console.WriteLine($"{order.OrderId} \t {order.orderDate} \t{order.OrderStatus}");
                    }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
        public static void DeleteProduct(ProductManager manager, int id)
        {
            Product product = new Product();
            try
            {
                product.pid = id;
                try
                {
                    foreach(var result in manager.ShowSearchedProducts(id))
                        if (result!=null)
                        {
                            if(manager.DeleteProductByID(id))
                            {
                                Console.WriteLine("Product deleted");
                                Console.WriteLine("--------------------------------------------------------");
                            }
                            else
                            {
                                Console.WriteLine("product not deleted !!");
                            }

                        }
                }
                catch (Exception)
                {

                    throw;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        public static void SearchProductByID(ProductManager manager, int productID)
        {
            // Product product = new Product();
            Product product = new Product();
            product.pid = productID;
            try
            {
                foreach (var result in manager.ShowSearchedProducts(productID))
                    if (result != null)
                    {
                        Console.WriteLine("Product ID \t Product Name \t\t Price \t Company ID \t Category ID \t Available Status \tImage URL");
                        DisplayRecords(result);
                        Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");

                    }
                    else
                    {
                        Console.WriteLine("There are no Products to Display");

                        Console.WriteLine("---------------------------------------------------------------------------------------------------------------------");
                    }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #region Insert Product Details
        public static void InsertRecords(ProductManager manager)
        {
            Product product = new Product();
            ILogger logger = new FileLogger();
            try
            {
                Console.WriteLine("Enter Product ID");
                product.pid = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Product Name");
                product.productName = Console.ReadLine();
                Console.WriteLine("Enter Product Price");
                product.price = double.Parse(Console.ReadLine());
                if (manager.AddProductByList(product))
                {
                    Console.WriteLine("Product Inserted");
                    logger.LogContent("Product Inserted ", "Insert Method Called ", DateTime.Now);
                    Console.WriteLine("--------------------------------------------------------");
                }
                else
                {
                    Console.WriteLine("Product Not Inserted");
                    Console.WriteLine("--------------------------------------------------------");
                }
            }
            catch (Exception e)
            {
                logger.LogContent(e.Message, e.StackTrace, DateTime.Now);
            }


        }
        #endregion

        #region Show Product Details       

        public static void ShowRecords(ProductManager manager)
        {
            ILogger logger = new FileLogger();
            try
            {
                foreach (var product in manager.ShowProductByList())
                {
                    if (product != null)
                    {
                        DisplayRecords(product);
                        Console.WriteLine("--------------------------------------------------------");
                        logger.LogContent("Product Displayed ", "Show Product Method Called ", DateTime.Now);
                    }
                    else
                    {
                        Console.WriteLine("There are no Products to Display");
                        logger.LogContent("No Record to Show");
                        Console.WriteLine("--------------------------------------------------------");
                    }
                }
            }
            catch (Exception e)
            {
                logger.LogContent(e.Message, e.StackTrace, DateTime.Now);
            }
            
        }
        #endregion
        public static void DisplayRecords(Product product)
        {
            Console.WriteLine($"{product.pid} \t \t {product.productName} \t {product.price} \t {product.CompanyId} \t \t {product.CategoryId} \t {product.availablestatus} \t\t {product.imageURL}\t{product.Company.companyName}");           
        }

        #region Search Records
        private static void SearchByID(ProductManager manager, int id)
        {
            Product product = new Product();
            ILogger logger = new FileLogger();
            product = manager.ShowSearchedRecords(id);
            try
            {
                if (product != null)
                {
                    DisplayRecords(product);
                }
                else
                {
                    Console.WriteLine($"No Product found for the entered ID:{id}");
                    Console.WriteLine("--------------------------------------------------------");
                    logger.LogContent("No Product found for the entered ID");
                }
            }
            catch (Exception e)
            {
                logger.LogContent(e.Message, e.StackTrace, DateTime.Now);
            }
        }
        #endregion        

        #region Update Records
        public static void UpdateRecord(ProductManager manager, int id)
        {
            Product product = new Product();
            ILogger logger = new FileLogger();
            try
            {
                product.pid = id;
                SearchByID(manager, id);
                product = manager.ShowSearchedRecords(id);
                if (product != null)
                {
                    Console.WriteLine("Enter Product Name");
                    product.productName = Console.ReadLine();
                    Console.WriteLine("Enter Product Price");
                    product.price = double.Parse(Console.ReadLine());
                    if (product != null)
                    {
                        manager.UpdateProduct(product);                        
                        ShowRecords(manager);
                        Console.WriteLine("Product Updated");
                        Console.WriteLine("--------------------------------------------------------");
                        logger.LogContent("Update Records ", "Update Method Called ", DateTime.Now);
                    }
                }                
                else
                {
                    Console.WriteLine("Please Start Again !!");
                    Console.WriteLine("--------------------------------------------------------");
                }

            }
            catch (Exception e)
            {
                logger.LogContent(e.Message, e.StackTrace, DateTime.Now);
            }

        } 
        #endregion

        #region Delete Records
        public static void DeleteRecord(ProductManager manager, int delid)
        {
            Product product = new Product();
            ILogger logger = new FileLogger();
            try
            {
                SearchByID(manager, delid);
                product = manager.ShowSearchedRecords(delid);
                if (product != null)
                {
                    manager.DeleteProduct(delid); 
                    Console.WriteLine("Product Deleted");
                    ShowRecords(manager);
                    Console.WriteLine("--------------------------------------------------------");
                }
                else
                {
                    Console.WriteLine("Please Start Again !!");
                    Console.WriteLine("--------------------------------------------------------");
                }

            }
            catch (Exception e)
            {
                logger.LogContent(e.Message, e.StackTrace, DateTime.Now);
            }

        }
        #endregion

        #region Sorting
        //public static void SortByPrice(ProductManager manager)
        //{            
        //    foreach (var prod in manager.SortByPrice())
        //    {
        //        DisplayRecords(prod);
        //    }
        //}

        //public static void SortByName(ProductManager manager)
        //{
        //    foreach (var prod in manager.SortByName())
        //    {
        //        DisplayRecords(prod);
        //    }
        //}

        public static void SortByPrice(ProductManager manager)
        {

            foreach (var product in manager.SortByPrice())
            {
                DisplayRecords(product);
            }
        }

        public static void SortByName(ProductManager manager)
        {
            foreach (var product in manager.SortByName())
            {
                DisplayRecords(product);
            }
        }
        #endregion

        //public static void InsertRecords(ProductManager manager)
        //{
        //    Product product = new Product();
        //    Console.WriteLine("Enter Product ID");
        //    product.pid = int.Parse(Console.ReadLine());
        //    Console.WriteLine("Enter Product Name");
        //    product.productName = Console.ReadLine();
        //    Console.WriteLine("Enter Product Price");
        //    product.price = double.Parse(Console.ReadLine());

        //    if (manager.AddProduct(product))
        //    {
        //        Console.WriteLine("Product Inserted");
        //    }
        //    else
        //    {
        //        Console.WriteLine("Product Not Inserted");
        //    }
        //}



        //public static void ShowRecords(ProductManager manager)
        //{
        //    foreach (var product in manager.ShowProduct())
        //    {
        //        DisplayRecords(product);
        //    }
        //}
    }
}
