﻿using CommonLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Contract
{
    public interface IDatabaseRepository
    {
        public IEnumerable<Product> GetProductFromDB(bool isEagerLoad = false);
        public IEnumerable<Customer> GetCustomersDetails();
        public bool InsertProduct(Product product);
        public bool UpdateProduct(Product product);
        public IEnumerable<Product> GetSearchedProduct(int id);
        public bool DeleteProduct(int id);
       // public IEnumerable<Product> GetProduct(int id);
        public Product GetProduct(int id);
        public IEnumerable<Product> ShowProducts(string key);
    }
}
