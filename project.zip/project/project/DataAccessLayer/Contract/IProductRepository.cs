﻿using CommonLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Contract
{
    public interface IProductManager
    {
        bool InsertRecord(Product product);

        Product GetProduct(int id);
        Product UpdateRecords(Product product);
        bool DeleteRecords(int id);
        public List<Product> SortByPrice();
        public List<Product> SortByName();
        public IEnumerable<Product> ShowProducts(string key);
    }
}
