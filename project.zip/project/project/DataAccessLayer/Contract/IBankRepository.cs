﻿using CommonLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Contract
{
    public interface IBankRepository
    {
        bool AddBank(Bank bank);
        bool UpdateBank(Bank bank);
        bool DeleteBank(int bankId);
        public IEnumerable<Bank> GetBanks();
    }
}
