﻿using CommonLayer.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Contract
{
    public interface ICompanyRepository
    {
        Company GetCompany(int id);
        public IEnumerable<Company> GetCompanyDetails();
        public bool InsertCompany(Company company);
        public bool UpdateCompany(Company company);
        public IEnumerable<Product> GetSearchedCompany(int id);
        public bool DeleteCompany(Company company);
    }
}
