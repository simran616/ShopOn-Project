﻿using CommonLayer.Model;
using System;

namespace DataAccessLayer
{
    public class ProductRepoInMemory
    {
        private Product[] products; // refernce variable of array Product
        private int index = -1;
        private int capacity=10;
        public ProductRepoInMemory()
        {
            this.products = new Product[capacity]; // initialized object 
        }

        public ProductRepoInMemory(int capacity)
        {
            this.capacity = capacity;
            this.products = new Product[capacity];
        }
        public bool InsertRecord(Product product)
        {
            bool IsInsert = false;
            if(index == this.products.Length-1)
            {
                var temp = new Product[this.products.Length];
                Array.Copy(this.products, temp, this.products.Length);
                this.products = new Product[this.products.Length * 2];
                Array.Copy(temp, this.products, temp.Length);
            }
            index++;
            this.products[index] = product;           
            IsInsert = true;
            return IsInsert;
        }

        public Product[] GetRecords()
        {
            index++;
            var temp = new Product[index];
            Array.Copy(this.products, temp, index);
            return temp;           
        }

        //public bool UpdateRecords(Product product)
        //{
        //    throw new NotImplementedException();
        //}

        //public bool DeleteRecords(int id)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
