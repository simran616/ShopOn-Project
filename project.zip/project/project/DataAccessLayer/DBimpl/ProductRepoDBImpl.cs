﻿using CommonLayer.Model;
using DataAccessLayer.Contract;
using DataAccessLayer.DBimpl;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopOn
{
    public class ProductRepoDBImpl : IDatabaseRepository
    {
        private readonly ICompanyRepository companyRepo = null;
        private List<Product> products; 
        public ProductRepoDBImpl()
        {
            this.products = new List<Product>();
            this.companyRepo = new CompanyRepositoryDBImpl();
        }            

        string connectionString = @"Data Source=GUUP-70914-WL\SQLEXPRESS;Initial Catalog=db_shopon;Integrated Security=True";

        /// <summary>
        /// Product Details from DB using sp
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Product> GetProductFromDB(bool isEagerLoad=false)
        {
            List<Product> products = new List<Product>();           
          
            #region Select Query
            //string query = @" SELECT pid,
            //                         productName,
            //                         price,
            //                         companyId,
            //                         categoryId, 
            //                         AvailableStatus, 
            //                         imageURL, 
            //                         isDeleted
            //                  FROM dbo.product WHERE isDeleted=0;"; 
            #endregion

            //Calling Sp
            string spName = "sp_GetProductDetails";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                  //SqlCommand command = new SqlCommand(query, connection);
                    SqlCommand command = new SqlCommand(spName, connection);
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataReader readData= command.ExecuteReader();                    
                    while(readData.Read())
                    {
                        Product product = new Product();
                        product.pid = Convert.ToInt32(readData["pid"]);
                        product.productName = readData["productName"].ToString();
                        product.price = Convert.ToInt32(readData["price"]);
                        product.CompanyId = Convert.ToInt32(readData["CompanyId"]);
                        product.CategoryId = Convert.ToInt32(readData["CategoryId"]);
                        product.availablestatus = readData["availablestatus"].ToString();
                        product.imageURL = readData["imageURL"].ToString();
                        //if(isEagerLoad)
                        //{
                        //    product.Company = companyRepo.GetCompany(product.CompanyId);
                        //}
                        isEagerLoad = true;
                        products.Add(product);
                    }
                   
                }               
                   
            }
            catch (Exception)
            {
                throw;
            }
            return products;
        }

        /// <summary>
        /// Customer Details from DB using query
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Customer> GetCustomersDetails()
        {
            List<Customer> customers = new List<Customer>();
            //string connectionString = @"Data Source=GUUP-70914-WL\SQLEXPRESS;Initial Catalog=db_shopon;Integrated Security=True";
            string query = @"SELECT 
                                    customerid,
                                    customername,
                                    mobileno,
                                    emailid,
                                    password 
                             FROM  dbo.customer";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Customer customer = new Customer();
                        customer.customerid = Convert.ToInt32(reader["customerid"]);
                        customer.customername = reader["customername"].ToString();
                        customer.mobileno = reader["mobileno"].ToString();
                        customer.emailid = reader["emailid"].ToString();
                        customer.password = reader["password"].ToString();
                        customers.Add(customer);

                    }
                }
                    
            }
            catch (Exception)
            {
                throw;
            }
           

            return customers;
        }

        public bool InsertProduct(Product product)
        {
            bool isInserted = false;
            //string query = @"insert into dbo.product(productname,price,companyid,categoryid,availablestatus,imageUrl,isDeleted)
            //               VALUES('"+ product.productName +"','"+product.price+"','"+product.CompanyId+"','"+product.CategoryId+"','"+product.availablestatus+"','"+product.imageURL+"','"+0+"');";
            string query = @"Insert into dbo.product(productname,price,companyid,categoryid,availablestatus,imageUrl,isDeleted)
                            VALUES(@productName,@price,@companyId,@CategoryId,@availablestatus,@imageUrl,@isDeleted)";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@productName", product.productName);
                    command.Parameters.AddWithValue("@price", product.price);
                    command.Parameters.AddWithValue("@companyId", product.CompanyId);
                    command.Parameters.AddWithValue("@CategoryId", product.CategoryId);
                    command.Parameters.AddWithValue("@availablestatus", product.availablestatus);
                    command.Parameters.AddWithValue("@imageUrl", product.imageURL);
                    command.Parameters.AddWithValue("@isDeleted", product.isDeleted);
                    int recordInserted = command.ExecuteNonQuery();
                    if (recordInserted>0)
                    {
                        isInserted = true;
                    }
                }

            }
            catch (Exception)
            {
                throw;
            }
            return isInserted;
        }

        public IEnumerable<Product> GetSearchedProduct(int id)
        {
            List<Product> products = new List<Product>();
            // return this.products.FirstOrDefault(x => x.pid == id);
            string sp = "sp_SeachProductbyID";
            try
            {
                using(SqlConnection connection=new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(sp, connection);
                    SqlParameter searchKeyword = command.Parameters.Add("@pid", SqlDbType.NVarChar);
                    searchKeyword.Value = id;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Product product = new Product();
                        product.pid = Convert.ToInt32(reader["pid"]);
                        product.productName = reader["productname"].ToString();
                        product.price = Convert.ToDouble(reader["price"]);
                        product.availablestatus = reader["availableStatus"].ToString();
                        product.imageURL = reader["imageUrl"].ToString();
                        product.CompanyId = Convert.ToInt32(reader["companyid"]);
                        product.CategoryId = Convert.ToInt32(reader["categoryid"]);
                        products.Add(product);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            return products;

        }
        public bool UpdateProduct(Product product)
        {
            bool isUpdated = false;
            string sp = "sp_UpdateProduct";
            try
            {
                using(SqlConnection connection= new SqlConnection(connectionString))
                {
                    
                    connection.Open();
                    SqlCommand command = new SqlCommand(sp, connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@pid", product.pid);
                    command.Parameters.AddWithValue("@productName", product.productName);
                    command.Parameters.AddWithValue("@price", product.price);
                    command.Parameters.AddWithValue("@companyId", product.CompanyId);
                    command.Parameters.AddWithValue("@CategoryId", product.CategoryId);
                    command.Parameters.AddWithValue("@availablestatus", product.availablestatus);
                    command.Parameters.AddWithValue("@imageUrl", product.imageURL);
                   
                    int recordUpdated = command.ExecuteNonQuery();
                    if (recordUpdated>0)
                    {
                        isUpdated = true;
                    }
                }

            }
            catch (Exception)
            {

                throw;
            }
            return isUpdated;
        }
        public bool DeleteProduct(int id)
        {
            bool isDeleted = false;
            string sp = "sp_DeleteProductbyID";
            try
            {
                using(SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(sp, connection);
                    SqlParameter searchKeyword = command.Parameters.Add("@pid", SqlDbType.NVarChar);
                    searchKeyword.Value = id;
                    command.CommandType = CommandType.StoredProcedure;
                    int recordDeleted = command.ExecuteNonQuery();
                    if(recordDeleted > 0)
                    {
                        isDeleted = true;
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            return isDeleted;
        }

        public Product GetProduct(int id)
        {
            // List<Product> products = new List<Product>();
            // return this.products.FirstOrDefault(x => x.pid == id);
            Product product = new Product();
            string sp = "sp_SeachProductbyID";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(sp, connection);
                    SqlParameter searchKeyword = command.Parameters.Add("@pid", SqlDbType.NVarChar);
                    searchKeyword.Value = id;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                       // Product product = new Product();
                        product.pid = Convert.ToInt32(reader["pid"]);
                        product.productName = reader["productname"].ToString();
                        product.price = Convert.ToDouble(reader["price"]);
                        product.availablestatus = reader["availableStatus"].ToString();
                        product.imageURL = reader["imageUrl"].ToString();
                        product.CompanyId = Convert.ToInt32(reader["companyid"]);
                        product.CategoryId = Convert.ToInt32(reader["categoryid"]);
                        //products.Add(product);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return product;
        }

        public IEnumerable<Product> ShowProducts(string key)
        {
            List<Product> products = new List<Product>();
            if(key !=null)
            {
                string sp = "sp_SearchByCompanyName";
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        SqlCommand command = new SqlCommand(sp, connection);
                        SqlParameter searchKeyword = command.Parameters.AddWithValue("@Keyword", key);
                        command.CommandType = CommandType.StoredProcedure;
                        SqlDataReader reader = command.ExecuteReader();
                        while (reader.Read())
                        {
                            Product product = new Product();
                            product.pid = Convert.ToInt32(reader["pid"]);
                            product.productName = reader["productname"].ToString();
                            product.price = Convert.ToDouble(reader["price"]);
                            product.availablestatus = reader["availableStatus"].ToString();
                            product.imageURL = reader["imageUrl"].ToString();
                            product.CompanyId = Convert.ToInt32(reader["companyid"]);
                            product.CategoryId = Convert.ToInt32(reader["categoryid"]);
                            products.Add(product);
                        }
                    }
                }
                catch (Exception e)
                {

                    Console.WriteLine(e.Message);
                    throw;
                }
            }
            else
            {
                GetProductFromDB(true);
            }           
            
            return products;
        }
    }
}
