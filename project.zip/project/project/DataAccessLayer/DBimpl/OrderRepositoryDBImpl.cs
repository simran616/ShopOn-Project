﻿using CommonLayer.Model;
using DataAccessLayer.Contract;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.DBimpl
{
    public class OrderRepositoryDBImpl : IOrderRepository
    {
        private List<Product> products;
        public OrderRepositoryDBImpl()
        {
            this.products = new List<Product>();
        }

        string connectionString = @"Data Source=GUUP-70914-WL\SQLEXPRESS;Initial Catalog=db_shopon;Integrated Security=True";

        //public bool AddOrder(Order order)
        //{
        //    bool isAdded = false;
        //    string query = @"Insert into dbo.orderd(orderstatus,orderdate,customerid,totalAmount)
        //                    VALUES(@orderstatus,@orderdate,@customerid,@totalAmount)";
        //    try
        //    {
        //        using (SqlConnection connection = new SqlConnection(connectionString))
        //        {
        //            connection.Open();
        //            SqlCommand command = new SqlCommand(query, connection);
        //            command.Parameters.AddWithValue("@orderstatus", order.OrderStatus);
        //            command.Parameters.AddWithValue("@orderdate", order.orderDate);
        //            command.Parameters.AddWithValue("@customerid", order.CustomerId);
        //            command.Parameters.AddWithValue("@totalAmount", order.OrderAmount);
        //            int recordInserted = command.ExecuteNonQuery();
        //            if (recordInserted > 0)
        //            {
        //                isAdded = true;
        //            }
        //        }

        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //    return isAdded;
            
        //}

        public bool AddOrder(Order order)
        {
            bool isAdded = false;
            SqlTransaction transaction = null;
            try
            {
                string spName = "[dbo].[sp_InsertOrder]";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    transaction = connection.BeginTransaction();
                    SqlCommand command = new SqlCommand(spName, connection, transaction);

                    SqlParameter customerIdParam = command.Parameters.Add("@CustomerId", SqlDbType.Int);
                    customerIdParam.Value = order.CustomerId;
                    customerIdParam.Direction = ParameterDirection.Input;

                    SqlParameter orderIdParam = command.Parameters.Add("@orderId", SqlDbType.Int);
                    orderIdParam.Direction = ParameterDirection.Output;

                    SqlParameter orderDateParam = command.Parameters.Add("@OrderDate", SqlDbType.DateTime);
                    orderDateParam.Value = order.orderDate;
                    orderDateParam.Direction = ParameterDirection.Input;

                    SqlParameter totalAmountParam = command.Parameters.Add("@Amount", SqlDbType.Float);
                    totalAmountParam.Value = order.GetTotalOrderValue(); 
                    totalAmountParam.Direction = ParameterDirection.Input;


                    command.CommandType = CommandType.StoredProcedure;
                    int returnCount = command.ExecuteNonQuery();
                    
                    if (returnCount > 0)
                    {
                        var newOrderId = Convert.ToInt32(command.Parameters["@orderId"].Value);                        
                        order.OrderId = newOrderId;
                        bool isOrderItemInserted = InsertOrderItem(order, connection, transaction);

                        if (isOrderItemInserted)
                        {
                            transaction.Commit();
                            isAdded = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                throw;
            }
            return isAdded;
        }

        public bool InsertOrderItem(Order order, SqlConnection connection, SqlTransaction transaction)
        {
            bool isInserted = false;
            foreach (var item in order.GetOrderItems())
            {
                string sqlstmt = "[dbo].[SP_InsertOrderItem]";
                SqlCommand command = new SqlCommand(sqlstmt, connection, transaction);

                SqlParameter orderIdParam = command.Parameters.Add("@orderId", SqlDbType.Int);
                orderIdParam.Direction = ParameterDirection.Input;
                orderIdParam.Value = order.OrderId;

                SqlParameter orderQuantityParam = command.Parameters.Add("@Quantity", SqlDbType.NVarChar);
                orderQuantityParam.Value = item.Qty;
                orderQuantityParam.Direction = ParameterDirection.Input;

                SqlParameter pidParam = command.Parameters.Add("@Pid", SqlDbType.Int);
                pidParam.Value = item.Pid;
                pidParam.Direction = ParameterDirection.Input;

                SqlParameter orderItemAmountParam = command.Parameters.Add("@Amount", SqlDbType.Float);
                orderItemAmountParam.Value = item.GetOrderAmount();
                orderItemAmountParam.Direction = ParameterDirection.Input;

                command.CommandType = CommandType.StoredProcedure;
                int returnCount = command.ExecuteNonQuery();
                if (returnCount > 0)
                {
                    isInserted = true;
                }
            }
            return isInserted;
        }

        public IEnumerable<Order> GetOrders()
        {
            List<Order> orders = new List<Order>();
            string spName = "sp_GetAllOrders";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    //SqlCommand command = new SqlCommand(query, connection);
                    SqlCommand command = new SqlCommand(spName, connection);
                    command.CommandType = CommandType.StoredProcedure;

                    SqlDataReader readData = command.ExecuteReader();
                    while (readData.Read())
                    {
                        Order order = new Order();
                        order.OrderId = Convert.ToInt32(readData["orderid"]);                        
                        order.orderDate = Convert.ToDateTime(readData["orderdate"]);
                        order.OrderStatus = readData["orderstatus"].ToString();                       
                        orders.Add(order);
                    }

                }

            }
            catch (Exception)
            {
                throw;
            }
            return orders;
        }
        public bool DeleteOrder(int id)
        {
            throw new NotImplementedException();
        }

        public bool UpdateOrder(Order order)
        {
            throw new NotImplementedException();
        }
    }
}
