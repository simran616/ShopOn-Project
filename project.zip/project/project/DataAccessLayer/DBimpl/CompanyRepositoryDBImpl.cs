﻿using CommonLayer.Model;
using DataAccessLayer.Contract;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.DBimpl
{
    public class CompanyRepositoryDBImpl : ICompanyRepository
    {
        //private readonly string connectionString = string.Empty;
        public CompanyRepositoryDBImpl()
        {
            //ConnectionUtil util = ConnectionUtil.getInstance();
            //this.connectionString = util.GetConnecytionString();
        }
        string connectionString = @"Data Source=GUUP-70914-WL\SQLEXPRESS;Initial Catalog=db_shopon;Integrated Security=True";

        public Company GetCompany(int id)
        {

            string query = @"Select c.companyid, c.companyname from dbo.company as c where c.companyid=@companyid";
            Company company = null;
            SqlDataAdapter adapter = null;
            DataSet dataSet = new DataSet();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    adapter = new SqlDataAdapter(query, connection);
                    adapter.Fill(dataSet, "Company");
                    DataTable dataTable = dataSet.Tables["Company"];
                    DataColumn[] dataColumn = new DataColumn[1];
                    dataColumn[0] = dataTable.Columns["companyid"];
                    dataTable.PrimaryKey = dataColumn;
                    var dr = dataTable.Rows.Find(id);
                    if (dr != null)
                    {
                        company = new Company();
                        company.companyId = Convert.ToInt32(dr["companyid"]);
                        company.companyName = dr["companyname"].ToString(); }

                }

            }
            catch (Exception)
            {
                throw;
            }
            return company;
        }
        public IEnumerable<Company> GetCompanyDetails()
        {
            List<Company> companies = new List<Company>();
            string query = @"Select c.companyid, c.companyname from dbo.company as c";
            SqlDataAdapter adapter = null;
            DataSet dataSet = new DataSet();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    adapter = new SqlDataAdapter(query, connection);
                    adapter.Fill(dataSet, "Company");
                    DataTable dataTable = dataSet.Tables["Company"];
                    foreach (DataRow row in dataTable.Rows)
                    {
                        Company company = new Company();
                        company.companyId = Convert.ToInt32(row["companyid"]);
                        company.companyName = row["companyname"].ToString();
                        companies.Add(company);
                    }


                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return companies;
        }

        public bool InsertCompany(Company company)
        {
            bool isInserted = false;
            string query = @"Select c.companyid, c.companyname, c.companyStatus, c.isdeleted from dbo.company as c";
            SqlDataAdapter adapter = null;
            DataSet dataSet = new DataSet();
            SqlCommandBuilder builder = null;
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    adapter = new SqlDataAdapter(query, connection);
                    adapter.Fill(dataSet, "Company");
                    builder = new SqlCommandBuilder(adapter);
                    DataRow dataRow = dataSet.Tables["Company"].NewRow();
                    //dataRow["companyid"] = company.companyId;
                    dataRow["companyname"] = company.companyName;
                    dataRow["companyStatus"] = company.companyStatus;
                    dataRow["isdeleted"] = company.isDeleted;
                    dataSet.Tables["Company"].Rows.Add(dataRow);
                    adapter.Update(dataSet, "Company");
                    isInserted = true;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return isInserted;           
           
        }

        public bool UpdateCompany(Company company)
        {
            bool isUpdated = false;
            string query = @"Select c.companyid, c.companyname, c.companyStatus, c.isdeleted from dbo.company as c";
            SqlDataAdapter adapter = null;
            DataSet dataSet = new DataSet();
            SqlCommandBuilder builder = null;
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    adapter = new SqlDataAdapter(query, connection);
                    adapter.Fill(dataSet, "Company");
                    builder = new SqlCommandBuilder(adapter);
                    DataTable table = dataSet.Tables["Company"];
                    DataColumn[] keyDataColumn = new DataColumn[1];
                    keyDataColumn[0] = table.Columns["CompanyId"];
                    table.PrimaryKey = keyDataColumn;
                    DataRow row = table.Rows.Find(company.companyId);

                    row["companyid"] = company.companyId;
                    row["companyname"] = company.companyName;
                    row["companystatus"] = company.companyStatus;                    
                    row["isdeleted"] = company.isDeleted;
                    adapter.Update(dataSet, "Company");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return isUpdated;
        }

        public IEnumerable<Product> GetSearchedCompany(int id)
        {
            throw new NotImplementedException();
        }

        public bool DeleteCompany(Company company)
        {
            bool isDeleted = false;
            string query = @"Select c.companyid, c.companyname, c.companyStatus, c.isdeleted from dbo.company as c";
            SqlDataAdapter adapter = null;
            DataSet dataSet = new DataSet();
            SqlCommandBuilder builder = null;
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    adapter = new SqlDataAdapter(query, connection);
                    adapter.Fill(dataSet, "Company");
                    builder = new SqlCommandBuilder(adapter);
                    DataTable table = dataSet.Tables["Company"];
                    DataColumn[] keyDataColumn = new DataColumn[1];
                    keyDataColumn[0] = table.Columns["CompanyId"];
                    table.PrimaryKey = keyDataColumn;
                    DataRow row = table.Rows.Find(company.companyId);
                    row["isdeleted"] = 1;
                    adapter.Update(dataSet, "Company");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return isDeleted;
        }

    }
}
