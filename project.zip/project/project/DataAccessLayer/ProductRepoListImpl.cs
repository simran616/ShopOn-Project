﻿using CommonLayer.Logger;
using CommonLayer.Model;
using DataAccessLayer.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class ProductRepoListImpl : IProductManager
    {

        private List<Product> products;       
        private ILogger logger = null;

        public ProductRepoListImpl()
        {
            this.products = new List<Product>();
            this.logger = new FileLogger();
        }
        //public List<Product> products = new List<Product>();
        
        public bool InsertRecord(Product product)
        {
            bool IsInsert = false;
            this.products.Add(product);
            IsInsert = true;
            return IsInsert;
        }

        public IEnumerable<Product> GetRecords()
        {
            return this.products;
        }

        public Product GetProduct(int id)
        {

            return this.products.FirstOrDefault(x => x.pid == id);
        }

        public Product UpdateRecords(Product product)
        {
            Product productTemp = null;
            try
            {
                
                foreach (var item in this.products)
                {
                    if (item.pid == product.pid)
                    {
                        productTemp = product;
                        item.price = product.price;
                        item.productName = product.productName;
                        break;
                        
                    }
                }
                //logger.LogContent("Product Updated");

            }
            catch (Exception e)
            {
                //logger.LogContent(e.Message);
            }
            
            return productTemp;
        }

        public bool DeleteRecords(int id)
        {
            bool isDelete = false;
            try
            {
                foreach (var item in this.products.ToList())
                {
                    if (item.pid == id)
                    {
                        this.products.Remove(item);
                    }
                }
            }
            catch (Exception)
            {
                //logger.LogContent("Product ID not deleted !!!");
            }
            
            isDelete = true;
            return isDelete;
        }

        //public IEnumerable<Product> SortByPrice()
        //{
        //    return this.products.OrderBy(o => o.price).ToList();
        //}

        //public IEnumerable<Product> SortByName()
        //{
        //    return this.products.OrderBy(o => o.productName).ToList();
        //}

        public List<Product> SortByPrice()
        {
            return this.products.OrderBy(o => o.price).ToList();

        }

        public List<Product> SortByName()
        {
            return this.products.OrderBy(o => o.productName).ToList();
        }

        public IEnumerable<Product> ShowProducts(string key)
        {
            throw new NotImplementedException();
        }
    }
}
