﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Utilities
{
    public class DBConnection
    {
        private string ConnectionString = string.Empty;
        private static DBConnection connectionUtil = new DBConnection();
        private DBConnection()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");
            IConfiguration configuration = builder.Build();
            ConnectionString = configuration.GetConnectionString("Default");
        }
        public static DBConnection GetInstance()
        {
            return connectionUtil;
        }

        public string GetConnectionString()
        {
            return this.ConnectionString;
        }
    }
}
