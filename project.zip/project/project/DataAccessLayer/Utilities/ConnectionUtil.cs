﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Utilities
{
    public class ConnectionUtil
    {
        string connectionString = @"Data Source=GUUP-70914-WL\SQLEXPRESS;Initial Catalog=db_shopon;Integrated Security=True";

        public ConnectionUtil connectionUtil = new ConnectionUtil();
        private ConnectionUtil()
        {

        }

        public static ConnectionUtil getInstance()
        {
            return connectionUtil;
        }

        public string GetConnecytionString()
        {
            return this.connectionString;
        }
    }
}
